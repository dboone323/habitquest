// SECURITY: API key handling - ensure proper encryption and keychain storage
//
//  PatternAnalysisView.swift
//  CodingReviewer
//
//  Phase 4: Pattern Recognition UI
//  Created on July 25, 2025
//

// MARK: - Pattern Analysis View

struct PatternAnalysisView: View {
    @StateObject private var patternEngine = PatternRecognitionEngine();
    @ObservedObject var viewModel: CodeReviewViewModel
    @State private var selectedTab: PatternTab = .patterns;
    @State private var isAnalyzing = false;

    enum PatternTab: String, CaseIterable {
        case patterns = "Design Patterns"
        case smells = "Code Smells"
        case performance = "Performance"

        var systemImage: String {
            switch self {
            case .patterns: return "brain.head.profile"
            case .smells: return "exclamationmark.triangle"
            case .performance: return "speedometer"
            }
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            VStack(spacing: 8) {
                HStack {
                    Text("Pattern Recognition")
                        .font(.title2)
                        .fontWeight(.bold)

                    Spacer()

                    if patternEngine.isAnalyzing {
                        ProgressView()
                            .scaleEffect(0.8)
                    }
                }

                Text("AI-powered design pattern detection and code smell analysis")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding()
            .background(Color(.controlBackgroundColor))

            // Tab Selection
            Picker("Analysis Type", selection: $selectedTab) {
                ForEach(PatternTab.allCases, id: \.self) { tab in
                    Label(tab.rawValue, systemImage: tab.systemImage)
                        .tag(tab)
                }
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)
            .padding(.top)

            // Analysis Button
            HStack {
                Button("Analyze Patterns") {
                    Task {
                        await analyzeCurrentCode()
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(viewModel.codeInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isAnalyzing)

                Spacer()

                if patternEngine.analysisProgress > 0 && patternEngine.analysisProgress < 1 {
                    ProgressView(value: patternEngine.analysisProgress, total: 1.0)
                        .frame(width: 100)
                }
            }
            .padding()

            Divider()

            // Content
            ScrollView {
                VStack(spacing: 16) {
                    switch selectedTab {
                    case .patterns:
                        PatternsContentView(patterns: patternEngine.detectedPatterns)
                    case .smells:
                        CodeSmellsContentView(smells: patternEngine.codeSmells)
                    case .performance:
                        PerformanceContentView(issues: patternEngine.performanceIssues)
                    }
                }
                .padding()
            }
        }
    }

    @MainActor
    private func analyzeCurrentCode() async {
        guard !viewModel.codeInput.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else { return }

        isAnalyzing = true

        // Analyze patterns
        _ = await patternEngine.detectDesignPatterns(
            in: viewModel.codeInput,
            language: viewModel.selectedLanguage
        )

        // Analyze code smells
        _ = await patternEngine.identifyCodeSmells(viewModel.analysisResults)

        // Analyze performance
        _ = await patternEngine.detectPerformanceBottlenecks(viewModel.codeInput)

        isAnalyzing = false
    }
}

// MARK: - Patterns Content View

struct PatternsContentView: View {
    let patterns: [DetectedPattern]

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if patterns.isEmpty {
                EmptyPatternStateView(
                    icon: "brain.head.profile",
                    title: "No Design Patterns Detected",
                    description: "Run pattern analysis on your code to discover design patterns."
                )
            } else {
                Text("Detected Design Patterns")
                    .font(.headline)

                ForEach(patterns) { pattern in
                    PatternCard(pattern: pattern)
                }
            }
        }
    }
}

// MARK: - Code Smells Content View

struct CodeSmellsContentView: View {
    let smells: [CodeSmell]

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if smells.isEmpty {
                EmptyPatternStateView(
                    icon: "checkmark.seal",
                    title: "No Code Smells Detected",
                    description: "Your code looks clean! Run analysis to check for potential issues."
                )
            } else {
                Text("Detected Code Smells")
                    .font(.headline)

                ForEach(smells) { smell in
                    CodeSmellCard(smell: smell)
                }
            }
        }
    }
}

// MARK: - Performance Content View

struct PerformanceContentView: View {
    let issues: [PerformanceIssue]

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if issues.isEmpty {
                EmptyPatternStateView(
                    icon: "speedometer",
                    title: "No Performance Issues Found",
                    description: "Your code appears to be well optimized. Great job!"
                )
            } else {
                Text("Performance Issues")
                    .font(.headline)

                ForEach(issues) { issue in
                    PerformanceIssueCard(issue: issue)
                }
            }
        }
    }
}

// MARK: - Individual Cards

struct PatternCard: View {
    let pattern: DetectedPattern
    @State private var isExpanded = false;

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(pattern.name)
                        .font(.headline)

                    Text(pattern.description)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text("\(pattern.confidencePercentage)%")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundColor(.blue)

                    Text("Confidence")
                        .font(.caption)
                        .foregroundColor(.secondary)

                    Button(action: { isExpanded.toggle() }) {
                        Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                    }
                    .buttonStyle(.borderless)
                }
            }

            if isExpanded {
                VStack(alignment: .leading, spacing: 8) {
                    Divider()

                    if let suggestion = pattern.suggestion {
                        Text("💡 Suggestion")
                            .font(.subheadline)
                            .fontWeight(.medium)

                        Text(suggestion)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }

                    if !pattern.relatedPatterns.isEmpty {
                        Text("🔗 Related Patterns")
                            .font(.subheadline)
                            .fontWeight(.medium)

                        Text(pattern.relatedPatterns.joined(separator: ", "))
                            .font(.caption)
                            .foregroundColor(.blue)
                    }
                }
            }
        }
        .padding()
        .background(Color.blue.opacity(0.1))
        .cornerRadius(8)
    }
}

struct CodeSmellCard: View {
    let smell: CodeSmell

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(smell.type.rawValue)
                        .font(.headline)

                    Text(smell.description)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text(smell.severity.rawValue)
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(smell.severity.color)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(smell.severity.color.opacity(0.2))
                        .cornerRadius(6)

                    Text("Line \(smell.location.line)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }

            Text("💡 " + smell.suggestion)
                .font(.caption)
                .foregroundColor(.secondary)
                .padding(.top, 4)
        }
        .padding()
        .background(smell.severity.color.opacity(0.1))
        .cornerRadius(8)
    }
}

struct PerformanceIssueCard: View {
    let issue: PerformanceIssue

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(issue.type.rawValue)
                        .font(.headline)

                    Text(issue.description)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text(issue.severity.rawValue)
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(issue.severity.color)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(issue.severity.color.opacity(0.2))
                        .cornerRadius(6)

                    Text(issue.estimatedImpact.rawValue)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }

            Text("🔧 " + issue.suggestion)
                .font(.caption)
                .foregroundColor(.secondary)
                .padding(.top, 4)
        }
        .padding()
        .background(Color.orange.opacity(0.1))
        .cornerRadius(8)
    }
}

// MARK: - Empty State View

struct EmptyPatternStateView: View {
    let icon: String
    let title: String
    let description: String

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 48))
                .foregroundColor(.gray)

            VStack(spacing: 8) {
                Text(title)
                    .font(.headline)
                    .fontWeight(.semibold)

                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity, minHeight: 200)
        .padding()
    }
}

#Preview {
    PatternAnalysisView(viewModel: CodeReviewViewModel(keyManager: APIKeyManager()))
}
